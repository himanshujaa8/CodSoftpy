import random
import string

def generate_password(length):
   
    lowercase_letters = string.ascii_lowercase
    uppercase_letters = string.ascii_uppercase
    digits = string.digits
    special_characters = string.punctuation

   
    character_set = lowercase_letters + uppercase_letters + digits + special_characters

   
    password = ''.join(random.choice(character_set) for _ in range(length))
    return password

def main():
    print("Welcome to the Password Generator!")

  
    while True:
        try:
            length = int(input("Enter the desired length of the password: "))
            break
        except ValueError:
            print("Invalid input. Please enter a valid number.")

   
    password = generate_password(length)
    print("Generated Password: ", password)

if __name__ == "__main__":
    main()
